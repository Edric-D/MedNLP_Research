import torch
from e1_head_only import select_device
print("PyTorch:", torch.__version__)
assert torch.cuda.is_available(), "CUDA unavailable: check NVIDIA driver and GPU access"
assert select_device(torch).type == "cuda"
print("GPU:", torch.cuda.get_device_name(0))
x = torch.randn(64, 64, device="cuda", requires_grad=True)
(x @ x).square().mean().backward()
torch.cuda.synchronize()
print("CUDA forward/backward OK")
